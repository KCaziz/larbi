import { prisma } from '../config/prisma.js';
import { NOTIFICATION_CATEGORIES, NOTIFICATION_FAMILIES, NOTIFICATION_TYPES } from '../constants/finNotification.js';
import { generateAlerts } from '../services/finAlerts.service.js';
import {
  countUnread,
  generateReminders,
  getNotificationSettings,
  listNotifications,
  markAllRead,
  markRead,
  updateNotificationSettings,
} from '../services/finNotification.service.js';

// Notifications and alerts (P6-18), screen C24. Session required everywhere;
// always this account's own rows.

export function getNotificationReferences(req, res) {
  // The families the person sets one by one (answer D7), each with its types.
  res.json({ categories: NOTIFICATION_CATEGORIES, families: NOTIFICATION_FAMILIES, types: NOTIFICATION_TYPES });
}

export async function getNotifications(req, res) {
  await generateReminders(prisma, req.user.id);
  // The client's twelve alerts (P8-18), read here as the reminders are.
  await generateAlerts(prisma, req.user);
  const notifications = await listNotifications(prisma, req.user.id, { category: req.query.category, read: req.query.read === undefined ? undefined : req.query.read === 'true' });
  res.json({ notifications, nonLues: notifications.filter((n) => !n.read).length });
}

// The badge of the top bar (P1-12): a number, nothing else.
export async function getUnreadCount(req, res) {
  res.json({ nonLues: await countUnread(prisma, req.user.id) });
}

export async function putNotificationRead(req, res) {
  const row = await markRead(prisma, req.user.id, req.params.id, req.body.read ?? true);
  if (!row) return res.status(404).json({ error: { message: 'Notification not found' } });
  res.json({ notification: row });
}

export async function postMarkAllRead(req, res) {
  res.json(await markAllRead(prisma, req.user.id));
}

export async function getSettings(req, res) {
  res.json({ parametres: await getNotificationSettings(prisma, req.user.id) });
}

export async function putSettings(req, res) {
  res.json({ parametres: await updateNotificationSettings(prisma, req.user.id, req.body) });
}
