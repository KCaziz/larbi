import { prisma } from '../config/prisma.js';
import { accountsWithBalances } from '../services/finAccount.service.js';
import {
  ASSET_KINDS,
  ASSET_LIQUIDITY,
  CONCENTRATION_NOTICE_SHARE,
  DEFAULT_LIQUIDITY,
  VALUATION_STALE_DAYS,
  WEALTH_STATUSES,
} from '../constants/finWealth.js';
import { listChanges } from '../services/finChange.service.js';
import { listDebts } from '../services/finDebt.service.js';
import {
  ASSET_ENTITY,
  buildWealthView,
  createAsset,
  deleteAsset,
  getAsset,
  listAssets,
  netWorthHistory,
  setAssetArchived,
  updateAsset,
  valuationHistory,
} from '../services/finWealth.service.js';
import { describeFormula } from '../services/finance/describe.js';
import { OFFICIAL_CURRENCY } from '../constants/finCurrencies.js';
import { counterValue, latestRates } from '../services/finExchange.service.js';

// Real patrimony (P6-11), screens C16 and JA07. Session required everywhere,
// and every read and write is scoped to the caller's own rows: what somebody
// owns is the most private figure in the platform.

export function getWealthReferences(req, res) {
  res.json({
    kinds: ASSET_KINDS,
    liquidity: ASSET_LIQUIDITY,
    defaultLiquidity: DEFAULT_LIQUIDITY,
    statuses: WEALTH_STATUSES,
    // Declared, not hidden: the client's own 90-day threshold, and the share
    // above which an educational note appears (ours).
    valuationStaleDays: VALUATION_STALE_DAYS,
    concentrationNoticeShare: CONCENTRATION_NOTICE_SHARE,
    // The client's sentence, published by the API so the interface can say it
    // rather than paraphrase it.
    fictionalForbidden: true,
    formulas: ['F035', 'F036', 'F037', 'F055'].map(describeFormula),
  });
}

export async function getAssets(req, res) {
  const assets = await listAssets(prisma, req.user.id, { includeArchived: req.query.includeArchived === 'true' });
  res.json({ assets });
}

export async function postAsset(req, res) {
  res.status(201).json({ asset: await createAsset(prisma, req.user.id, req.body) });
}

export async function patchAsset(req, res) {
  res.json({ asset: await updateAsset(prisma, req.user.id, req.params.id, req.body) });
}

export async function putAssetArchived(req, res) {
  const { archived, reason } = req.body;
  res.json({ asset: await setAssetArchived(prisma, req.user.id, req.params.id, archived, { reason }) });
}

export async function removeAsset(req, res) {
  res.json(await deleteAsset(prisma, req.user.id, req.params.id, { reason: req.body?.reason }));
}

export async function getAssetHistory(req, res) {
  // Ownership first: the trail of a row that is not the caller's is a 404.
  await getAsset(prisma, req.user.id, req.params.id);
  const changes = await listChanges(prisma, { userId: req.user.id, entity: ASSET_ENTITY, entityId: req.params.id });
  res.json({ changes });
}

// The valuation series, read from the correction journal rather than from a
// second table of the same facts.
export async function getAssetValuations(req, res) {
  res.json({ valuations: await valuationHistory(prisma, req.user.id, req.params.id) });
}

// The history behind the patrimony's net-worth curve (P6-23). Same currency
// default as `getWealth`, so a caller who never passes `?currency=` sees the
// series line up with the figure it leads to.
export async function getWealthHistory(req, res) {
  const currency = req.query.currency ?? req.user.finCurrency;
  res.json({ currency, points: await accountsNetWorthHistory(prisma, req.user.id, currency) });
}

/**
 * The net worth at the end of each of the last twelve months, read like the
 * patrimony itself (P8-24): the accounts counted in the net worth as they stood
 * at that date (PB-F001 then), the declared assets of the other classes valued
 * by then, and the debts as the correction journal had them. A person with no
 * account keeps the former series, which reads the declared assets only.
 */
export async function accountsNetWorthHistory(prisma, userId, currency, { months = 12, now = new Date() } = {}) {
  if ((await prisma.finAccount.count({ where: { userId, deletedAt: null } })) === 0) return netWorthHistory(prisma, userId, currency);
  const [declared, debts] = await Promise.all([listAssets(prisma, userId), listDebts(prisma, userId)]);
  const points = [];
  for (let back = months - 1; back >= 0; back -= 1) {
    const end = new Date(Math.min(now.getTime(), Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - back + 1, 1) - 1));
    const { accounts } = await accountsWithBalances(prisma, userId, { includeArchived: true, now: end });
    // An account that did not exist yet contributes nothing, rather than its
    // opening balance read backwards.
    const existing = accounts.filter((account) => new Date(account.openingDate) <= end);
    const { assets, liabilities } = wealthFromAccounts({
      declared: declared.filter((asset) => asset.valuedAt <= end),
      // A debt carried by an account is counted through it; the others as they
      // stand today: their own history is not kept as dated balances.
      debts: debts.filter((debt) => !debt.accountId),
      accounts: existing,
      now: end,
    });
    const sum = (rows, field) => rows.filter((row) => row.currency === currency).reduce((total, row) => total + row[field], 0);
    points.push({ date: end.toISOString().slice(0, 10), net: sum(assets, 'value') - sum(liabilities, 'outstandingPrincipal') });
  }
  return points;
}

async function inOfficialCurrency({ assets, liabilities }) {
  if (![...assets, ...liabilities].some((row) => row.currency !== OFFICIAL_CURRENCY)) return { assets, liabilities };
  const rates = await latestRates(prisma);
  const convert = (row, field) => {
    if (row.currency === OFFICIAL_CURRENCY) return row;
    const cv = counterValue(row[field], row.currency, rates);
    if (!cv) return row;
    return { ...row, [field]: cv.value, currency: OFFICIAL_CURRENCY, devise: { currency: row.currency, value: row[field], rate: cv.rate, referenceDate: cv.referenceDate } };
  };
  return { assets: assets.map((row) => convert(row, 'value')), liabilities: liabilities.map((row) => convert(row, 'outstandingPrincipal')) };
}

export async function getWealth(req, res) {
  const currency = req.query.currency ?? req.user.finCurrency;
  const [declared, debts, { accounts }] = await Promise.all([listAssets(prisma, req.user.id), listDebts(prisma, req.user.id), accountsWithBalances(prisma, req.user.id)]);
  const found = wealthFromAccounts({ declared, debts, accounts });
  // P10-05: what is held in a foreign currency stays in it, and counts in the
  // patrimony for its counter-value in dinars at the official rate of a
  // reference date. Without an official rate, it is left out and said so.
  const { assets, liabilities } = currency === OFFICIAL_CURRENCY ? await inOfficialCurrency(found) : found;
  const { notCounted } = found;
  const view = buildWealthView({
    assets,
    debts: liabilities,
    currency,
    staleDays: req.query.staleDays ?? VALUATION_STALE_DAYS,
    noticeShare: req.query.noticeShare ?? CONCENTRATION_NOTICE_SHARE,
  });

  // The labels the rows need, joined here so the interface never guesses what a
  // category is called.
  const ids = [...new Set(view.actifs.map((row) => row.categoryId).filter(Boolean))];
  const labels = new Map(
    (await prisma.finCategory.findMany({ where: { id: { in: ids } }, select: { id: true, label: true } })).map((row) => [row.id, row.label]),
  );
  view.actifs = view.actifs.map((row) => ({ ...row, categoryLabel: row.categoryId ? (labels.get(row.categoryId) ?? null) : null }));

  view.nonComptes = notCounted;
  res.json({ patrimoine: view, formulas: ['PB-F024', 'F036', 'F037'].map(describeFormula) });
}

// The kinds of declared asset an account now stands for: once the person has
// accounts, cash and bank balances come from them, never typed a second time.
const LIQUID_DECLARED = ['cash', 'account', 'ccp'];
// Recette R9-19: which account types stand for which declared kind. A declared
// CCP is left out only when a CCP account holds it — not because some other
// account exists (the « Espèces » account opens on its own at the first
// expense, and used to make every declared bank balance vanish).
const ACCOUNT_TYPES_OF = { cash: ['AC-01'], ccp: ['AC-03'], account: ['AC-02', 'AC-04'] };
const LIQUIDITY_OF = { liquid: 'liquid', savings: 'liquid', investment: 'semi_liquid', receivable: 'illiquid', configurable: 'semi_liquid' };

/**
 * The patrimony of P8-14 (PB-F003, PB-F024), without counting anything twice:
 * - the liquidities come AUTOMATICALLY from the accounts counted in the net
 *   worth (their balance, PB-F001); a declared cash or bank asset is then
 *   left out, the account already holds it;
 * - the other classes (real estate, gold, vehicle, business, real
 *   investments) stay declared and dated;
 * - the liabilities are the debts, plus the liability accounts (cards,
 *   loans) — a debt carried by an account is counted once, through it;
 * - a receivable (« J'ai prêté ») is an ASSET, never a liability.
 */
export function wealthFromAccounts({ declared, debts, accounts, now = new Date() }) {
  const open = accounts.filter((account) => !account.archivedAt && account.includeInNetWorth);
  // The types held by accounts the person opened (not the automatic one).
  const heldTypes = new Set(open.filter((account) => account.source !== 'computed').map((account) => account.type));
  const representedByAccount = (asset) => LIQUID_DECLARED.includes(asset.kind) && (ACCOUNT_TYPES_OF[asset.kind] ?? []).some((type) => heldTypes.has(type));
  const fromAccounts = open
    .filter((account) => !account.liability && account.solde.resultat !== null && account.solde.resultat > 0)
    .map((account) => ({
      id: `account:${account.id}`,
      label: account.label,
      kind: account.nature === 'receivable' ? 'receivable' : account.nature === 'investment' ? 'investment' : 'account',
      liquidity: LIQUIDITY_OF[account.nature] ?? 'liquid',
      value: account.solde.resultat,
      currency: account.currency,
      valuedAt: now,
      categoryId: null,
      status: 'real',
      fromAccount: true,
    }));
  const liabilityAccounts = open
    .filter((account) => account.liability && account.solde.resultat !== null && account.solde.resultat > 0)
    .map((account) => ({ id: `account:${account.id}`, outstandingPrincipal: account.solde.resultat, currency: account.currency }));
  // Recette R9-19: an account in the red (an overdraft) is money owed. It used
  // to be counted neither as an asset nor as a debt, so the net worth did not
  // match the net position of the accounts.
  const overdrawn = open
    .filter((account) => !account.liability && account.solde.resultat !== null && account.solde.resultat < 0)
    .map((account) => ({ id: `overdraft:${account.id}`, label: account.label, outstandingPrincipal: -account.solde.resultat, currency: account.currency }));

  const assets = [...fromAccounts, ...declared.filter((asset) => !representedByAccount(asset))];
  // A receivable without its own account is still an asset.
  for (const debt of debts.filter((row) => row.direction === 'lent' && !row.accountId && row.outstandingPrincipal > 0)) {
    assets.push({ id: `receivable:${debt.id}`, label: debt.label, kind: 'receivable', liquidity: 'illiquid', value: debt.outstandingPrincipal, currency: debt.currency, valuedAt: now, categoryId: null, status: 'real' });
  }
  const liabilities = [...debts.filter((row) => row.direction !== 'lent' && !row.accountId), ...liabilityAccounts, ...overdrawn];
  // What is NOT counted, and why — said on the screen (recette R9-19).
  const notCounted = [
    ...declared.filter(representedByAccount).map((asset) => ({ label: asset.label, reason: 'heldByAccount' })),
    ...accounts.filter((account) => !account.archivedAt && !account.includeInNetWorth).map((account) => ({ label: account.label, reason: 'accountExcluded' })),
  ];
  return { assets, liabilities, notCounted };
}
