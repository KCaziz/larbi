import { Router } from 'express';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { receiveFile } from '../middleware/upload.js';
import { validateBody } from '../middleware/validate.js';
import { CONTENT_LANGUAGES } from '../constants/blog.js';
import { ROLES } from '../constants/roles.js';
import { HttpError } from '../utils/httpError.js';
import { asyncRoute, uuidParam } from '../utils/asyncRoute.js';
import {
  createCategory,
  createFormation,
  deleteFormation,
  getFormation,
  listCategories,
  listFormations,
  publishFormation,
  setFormationStatus,
  unpublishFormation,
  updateFormation,
} from '../controllers/admin/formations.controller.js';
import {
  createBlock,
  createRevision,
  deleteBlock,
  duplicateBlock,
  listRevisions,
  reorderBlocks,
  restoreRevision,
  updateBlock,
  uploadBlockFile,
} from '../controllers/admin/blocks.controller.js';
import { createBlockSchema, createRevisionSchema, reorderBlocksSchema, updateBlockSchema } from '../validation/blocks.schemas.js';
import {
  createQuestion,
  createQuiz,
  deleteQuestion,
  deleteQuiz,
  getQuiz,
  reorderQuestions,
  updateQuestion,
  updateQuiz,
} from '../controllers/admin/quizzes.controller.js';
import {
  createQuestionSchema,
  createQuizSchema,
  reorderQuestionsSchema,
  updateQuestionSchema,
  updateQuizSchema,
} from '../validation/quiz.schemas.js';
import { duplicateFormationRoute, duplicateLessonRoute, duplicateSectionRoute } from '../controllers/admin/duplicate.controller.js';
import { createSection, deleteSection, saveOutline, updateSection } from '../controllers/admin/sections.controller.js';
import { getDashboard } from '../controllers/admin/dashboard.controller.js';
import { createCourse, deleteCourse, reorderCourses, updateCourse } from '../controllers/admin/courses.controller.js';
import {
  createArticle,
  createArticleCategory,
  deleteArticle,
  getArticle,
  listArticleCategories,
  listArticles,
  listTags,
  publishArticle,
  unpublishArticle,
  updateArticle,
  getTranslation,
  saveTranslation,
  deleteTranslation,
  duplicateTranslation,
} from '../controllers/admin/articles.controller.js';
import {
  deleteSubscriber,
  exportSubscribers,
  listSubscribers,
  previewDigest,
} from '../controllers/admin/newsletter.controller.js';
import { validateQuery } from '../middleware/validate.js';
import { digestQuerySchema, subscribersQuerySchema } from '../validation/newsletter.schemas.js';
import {
  deleteMedia,
  listMedia,
  serveMedia,
  uploadArticleCover,
  uploadArticleMedia,
  uploadCourseMedia,
  uploadCover,
} from '../controllers/admin/media.controller.js';
import { createArticleSchema, translationSchema, updateArticleSchema } from '../validation/blog.schemas.js';
import {
  createCategorySchema,
  createCourseSchema,
  createFormationSchema,
  createSectionSchema,
  outlineSchema,
  statusSchema,
  updateSectionSchema,
  reorderCoursesSchema,
  updateCourseSchema,
  updateFormationSchema,
} from '../validation/cms.schemas.js';
import { mediaQuerySchema } from '../validation/media.schemas.js';
import {
  createAccountType,
  deleteAccountType,
  listAccountTypes,
  updateAccountType,
} from '../controllers/admin/accountTypes.controller.js';
import { createAccountTypeSchema, updateAccountTypeSchema } from '../validation/accountTypes.schemas.js';
import { getUser, listUsers, updateUser } from '../controllers/admin/users.controller.js';
import { updateUserSchema, usersQuerySchema } from '../validation/users.schemas.js';
import { listSettings, upsertSettingRoute } from '../controllers/admin/settings.controller.js';
import { upsertSettingSchema } from '../validation/settings.schemas.js';
import {
  listCertificates,
  restoreCertificate,
  revokeCertificate,
} from '../controllers/admin/certificates.controller.js';
import { certificatesQuerySchema, revokeCertificateSchema } from '../validation/certificates.schemas.js';
import {
  createBank,
  createCondition,
  deleteBank,
  deleteCondition,
  listBanks,
  listConditions,
  renameBank,
  updateCondition,
} from '../controllers/admin/comparator.controller.js';
import {
  createChatbotEntry,
  deleteChatbotEntry,
  listChatbotEntries,
  publishChatbotEntry,
  reorderChatbotEntries,
  unpublishChatbotEntry,
  updateChatbotEntry,
} from '../controllers/admin/chatbot.controller.js';
import { createChatbotEntrySchema, reorderChatbotSchema, updateChatbotEntrySchema } from '../validation/chatbot.schemas.js';
import { createOffer, deleteOffer, listOffersAdmin, listOrdersAdmin, updateOffer } from '../controllers/admin/payments.controller.js';
import { createOfferSchema, ordersQuerySchema, updateOfferSchema } from '../validation/payments.schemas.js';
import {
  createGuide,
  createTerm,
  deleteGuide,
  deleteTerm,
  getGuide,
  getTerm,
  listGuides,
  listTermRevisions,
  listTerms,
  publishGuide,
  publishTerm,
  reorderGuides,
  unpublishGuide,
  unpublishTerm,
  updateGuide,
  updateTerm,
} from '../controllers/admin/glossary.controller.js';
import { createGuideSchema, createTermSchema, reorderGuidesSchema, updateGuideSchema, updateTermSchema } from '../validation/glossary.schemas.js';
import {
  createFlow,
  createStep,
  deleteFlow,
  deleteStep,
  getFlow as getFlowAdmin,
  listAuditLog,
  listFlows,
  listIntents,
  publishFlow,
  publishIntent,
  unpublishFlow,
  unpublishIntent,
  updateIntent,
  updateStep,
} from '../controllers/admin/finAssistant.controller.js';
import { createMission, deleteMission, listMissionsAdmin, setMissionStatus, updateMission } from '../services/finMission.service.js';
import { createMissionSchema, updateMissionSchema } from '../validation/finMissions.schemas.js';
import { prisma as missionPrisma } from '../config/prisma.js';
import { createFlowSchema, createStepSchema, updateIntentSchema, updateStepSchema } from '../validation/finAssistant.schemas.js';
import { bankSchema, conditionsQuerySchema, createConditionSchema, updateConditionSchema } from '../validation/comparator.schemas.js';

// CMS administration API. EVERY route below requires an authenticated admin,
// checked here on the server (the React admin area is only a convenience).
// The CMS base is shared: articles (P3-02) add their routes to this router.
const router = Router();
router.use(requireAuth, requireRole(ROLES.ADMIN));
router.param('id', uuidParam);
router.param('revisionId', uuidParam);
router.param('stepId', uuidParam);

// Formations
router.get('/formations', asyncRoute(listFormations));
router.post('/formations', validateBody(createFormationSchema), asyncRoute(createFormation));
router.get('/formations/:id', asyncRoute(getFormation));
router.patch('/formations/:id', validateBody(updateFormationSchema), asyncRoute(updateFormation));
router.delete('/formations/:id', asyncRoute(deleteFormation));
router.post('/formations/:id/publish', asyncRoute(publishFormation));
router.post('/formations/:id/unpublish', asyncRoute(unpublishFormation));
router.post('/formations/:id/cover', receiveFile, asyncRoute(uploadCover));

// Courses of a formation
router.get('/dashboard', asyncRoute(getDashboard));
// Duplication (P3-14)
router.post('/formations/:id/duplicate', asyncRoute(duplicateFormationRoute));
router.post('/sections/:id/duplicate', asyncRoute(duplicateSectionRoute));
router.post('/courses/:id/duplicate', asyncRoute(duplicateLessonRoute));
router.put('/formations/:id/status', validateBody(statusSchema), asyncRoute(setFormationStatus));
router.post('/formations/:id/sections', validateBody(createSectionSchema), asyncRoute(createSection));
router.put('/formations/:id/outline', validateBody(outlineSchema), asyncRoute(saveOutline));
router.patch('/sections/:id', validateBody(updateSectionSchema), asyncRoute(updateSection));
router.delete('/sections/:id', asyncRoute(deleteSection));
router.post('/formations/:id/courses', validateBody(createCourseSchema), asyncRoute(createCourse));
router.put('/formations/:id/courses/order', validateBody(reorderCoursesSchema), asyncRoute(reorderCourses));
router.patch('/courses/:id', validateBody(updateCourseSchema), asyncRoute(updateCourse));
router.delete('/courses/:id', asyncRoute(deleteCourse));
// Quizzes (P3-13)
router.post('/formations/:id/quizzes', validateBody(createQuizSchema), asyncRoute(createQuiz));
router.get('/quizzes/:id', asyncRoute(getQuiz));
router.patch('/quizzes/:id', validateBody(updateQuizSchema), asyncRoute(updateQuiz));
router.delete('/quizzes/:id', asyncRoute(deleteQuiz));
router.post('/quizzes/:id/questions', validateBody(createQuestionSchema), asyncRoute(createQuestion));
router.put('/quizzes/:id/questions/order', validateBody(reorderQuestionsSchema), asyncRoute(reorderQuestions));
router.patch('/questions/:id', validateBody(updateQuestionSchema), asyncRoute(updateQuestion));
router.delete('/questions/:id', asyncRoute(deleteQuestion));

// Blocks of a lesson (P3-12)
router.post('/courses/:id/blocks', validateBody(createBlockSchema), asyncRoute(createBlock));
router.post('/courses/:id/blocks/upload', receiveFile, asyncRoute(uploadBlockFile));
router.put('/courses/:id/blocks/order', validateBody(reorderBlocksSchema), asyncRoute(reorderBlocks));
router.patch('/blocks/:id', validateBody(updateBlockSchema), asyncRoute(updateBlock));
router.post('/blocks/:id/duplicate', asyncRoute(duplicateBlock));
router.delete('/blocks/:id', asyncRoute(deleteBlock));
router.get('/courses/:id/revisions', asyncRoute(listRevisions));
router.post('/courses/:id/revisions', validateBody(createRevisionSchema), asyncRoute(createRevision));
router.post('/courses/:id/revisions/:revisionId/restore', asyncRoute(restoreRevision));
router.post('/courses/:id/media', receiveFile, asyncRoute(uploadCourseMedia));

// Blog articles (P3-02)
router.get('/articles', asyncRoute(listArticles));
router.post('/articles', validateBody(createArticleSchema), asyncRoute(createArticle));
router.get('/articles/:id', asyncRoute(getArticle));
router.patch('/articles/:id', validateBody(updateArticleSchema), asyncRoute(updateArticle));
router.delete('/articles/:id', asyncRoute(deleteArticle));
// Translations of an article (one per language other than its own).
router.param('lang', (req, res, next, value) => (CONTENT_LANGUAGES.includes(value) ? next() : next(new HttpError(404, 'Not found'))));
router.get('/articles/:id/translations/:lang', asyncRoute(getTranslation));
router.put('/articles/:id/translations/:lang', validateBody(translationSchema), asyncRoute(saveTranslation));
// Starts a translation from a copy of the article's own text, straight from the
// articles list (no need to open the editor first): still one row per language,
// just filled in already instead of blank.
router.post('/articles/:id/translations/:lang/duplicate', asyncRoute(duplicateTranslation));
router.delete('/articles/:id/translations/:lang', asyncRoute(deleteTranslation));
router.post('/articles/:id/publish', asyncRoute(publishArticle));
router.post('/articles/:id/unpublish', asyncRoute(unpublishArticle));
router.post('/articles/:id/cover', receiveFile, asyncRoute(uploadArticleCover));
router.post('/articles/:id/media', receiveFile, asyncRoute(uploadArticleMedia));
router.get('/article-categories', asyncRoute(listArticleCategories));
router.post('/article-categories', validateBody(createCategorySchema), asyncRoute(createArticleCategory));
router.get('/tags', asyncRoute(listTags));

// Media
router.get('/media', validateQuery(mediaQuerySchema), asyncRoute(listMedia));
router.get('/media/:id/file', asyncRoute(serveMedia));
router.delete('/media/:id', asyncRoute(deleteMedia));

// Categories
router.get('/categories', asyncRoute(listCategories));
router.post('/categories', validateBody(createCategorySchema), asyncRoute(createCategory));

// Newsletter (P3-05)
router.get('/newsletter/subscribers', validateQuery(subscribersQuerySchema), asyncRoute(listSubscribers));
router.get('/newsletter/subscribers.csv', validateQuery(subscribersQuerySchema), asyncRoute(exportSubscribers));
router.delete('/newsletter/subscribers/:id', asyncRoute(deleteSubscriber));
router.get('/newsletter/digest', validateQuery(digestQuerySchema), asyncRoute(previewDigest));

// Account types (P3-15)
router.get('/account-types', asyncRoute(listAccountTypes));
router.post('/account-types', validateBody(createAccountTypeSchema), asyncRoute(createAccountType));
router.patch('/account-types/:id', validateBody(updateAccountTypeSchema), asyncRoute(updateAccountType));
router.delete('/account-types/:id', asyncRoute(deleteAccountType));

// Users, rights and access (P3-16)
router.get('/users', validateQuery(usersQuerySchema), asyncRoute(listUsers));
router.get('/users/:id', asyncRoute(getUser));
router.patch('/users/:id', validateBody(updateUserSchema), asyncRoute(updateUser));

// Platform settings (P3-16)
router.get('/settings', asyncRoute(listSettings));
router.post('/settings', validateBody(upsertSettingSchema), asyncRoute(upsertSettingRoute));

// Certificates (P3-16)
router.get('/certificates', validateQuery(certificatesQuerySchema), asyncRoute(listCertificates));
router.post('/certificates/:id/revoke', validateBody(revokeCertificateSchema), asyncRoute(revokeCertificate));
router.post('/certificates/:id/restore', asyncRoute(restoreCertificate));

// Bank comparator (P4-08): banks and their conditions, rubric by rubric.
router.get('/comparator/banks', asyncRoute(listBanks));
router.post('/comparator/banks', validateBody(bankSchema), asyncRoute(createBank));
router.patch('/comparator/banks/:id', validateBody(bankSchema), asyncRoute(renameBank));
router.delete('/comparator/banks/:id', asyncRoute(deleteBank));
router.get('/comparator/conditions', validateQuery(conditionsQuerySchema), asyncRoute(listConditions));
router.post('/comparator/conditions', validateBody(createConditionSchema), asyncRoute(createCondition));
router.patch('/comparator/conditions/:id', validateBody(updateConditionSchema), asyncRoute(updateCondition));
router.delete('/comparator/conditions/:id', asyncRoute(deleteCondition));

// Guided assistant (P3-07): questions and answers shown in the public panel.
router.get('/chatbot', asyncRoute(listChatbotEntries));
router.post('/chatbot', validateBody(createChatbotEntrySchema), asyncRoute(createChatbotEntry));
router.put('/chatbot/order', validateBody(reorderChatbotSchema), asyncRoute(reorderChatbotEntries));
router.patch('/chatbot/:id', validateBody(updateChatbotEntrySchema), asyncRoute(updateChatbotEntry));
router.post('/chatbot/:id/publish', asyncRoute(publishChatbotEntry));
router.post('/chatbot/:id/unpublish', asyncRoute(unpublishChatbotEntry));
router.delete('/chatbot/:id', asyncRoute(deleteChatbotEntry));

// Payment (P3-09): offers, and the orders in READ-ONLY (their status only
// changes through authentic provider notifications).
router.get('/payments/offers', asyncRoute(listOffersAdmin));
router.post('/payments/offers', validateBody(createOfferSchema), asyncRoute(createOffer));
router.patch('/payments/offers/:id', validateBody(updateOfferSchema), asyncRoute(updateOffer));
router.delete('/payments/offers/:id', asyncRoute(deleteOffer));
router.get('/payments/orders', validateQuery(ordersQuerySchema), asyncRoute(listOrdersAdmin));

// "Apprendre" glossary and mini-guides (P2-08).
router.get('/glossary/terms', asyncRoute(listTerms));
router.post('/glossary/terms', validateBody(createTermSchema), asyncRoute(createTerm));
router.get('/glossary/terms/:id', asyncRoute(getTerm));
router.patch('/glossary/terms/:id', validateBody(updateTermSchema), asyncRoute(updateTerm));
router.delete('/glossary/terms/:id', asyncRoute(deleteTerm));
router.get('/glossary/terms/:id/revisions', asyncRoute(listTermRevisions));
router.post('/glossary/terms/:id/publish', asyncRoute(publishTerm));
router.post('/glossary/terms/:id/unpublish', asyncRoute(unpublishTerm));
router.get('/glossary/guides', asyncRoute(listGuides));
router.post('/glossary/guides', validateBody(createGuideSchema), asyncRoute(createGuide));
router.get('/glossary/guides/:id', asyncRoute(getGuide));
router.patch('/glossary/guides/:id', validateBody(updateGuideSchema), asyncRoute(updateGuide));
router.put('/glossary/guides/order', validateBody(reorderGuidesSchema), asyncRoute(reorderGuides));
router.post('/glossary/guides/:id/publish', asyncRoute(publishGuide));
router.post('/glossary/guides/:id/unpublish', asyncRoute(unpublishGuide));
router.delete('/glossary/guides/:id', asyncRoute(deleteGuide));

// Pedagogical missions (P8-17): entered by an administrator from the client's contents.
router.get('/fin-missions', asyncRoute(async (req, res) => res.json({ missions: await listMissionsAdmin(missionPrisma) })));
router.post('/fin-missions', validateBody(createMissionSchema), asyncRoute(async (req, res) => res.status(201).json({ mission: await createMission(missionPrisma, req.body) })));
router.patch('/fin-missions/:id', validateBody(updateMissionSchema), asyncRoute(async (req, res) => res.json({ mission: await updateMission(missionPrisma, req.params.id, req.body) })));
router.post('/fin-missions/:id/publish', asyncRoute(async (req, res) => res.json({ mission: await setMissionStatus(missionPrisma, req.params.id, 'published') })));
router.post('/fin-missions/:id/unpublish', asyncRoute(async (req, res) => res.json({ mission: await setMissionStatus(missionPrisma, req.params.id, 'draft') })));
router.delete('/fin-missions/:id', asyncRoute(async (req, res) => res.json(await deleteMission(missionPrisma, req.params.id))));

// FINCLUDIA deterministic assistant (P3-19).
router.get('/fin-assistant/intents', asyncRoute(listIntents));
router.patch('/fin-assistant/intents/:id', validateBody(updateIntentSchema), asyncRoute(updateIntent));
router.post('/fin-assistant/intents/:id/publish', asyncRoute(publishIntent));
router.post('/fin-assistant/intents/:id/unpublish', asyncRoute(unpublishIntent));
router.get('/fin-assistant/flows', asyncRoute(listFlows));
router.post('/fin-assistant/flows', validateBody(createFlowSchema), asyncRoute(createFlow));
router.get('/fin-assistant/flows/:id', asyncRoute(getFlowAdmin));
router.post('/fin-assistant/flows/:id/publish', asyncRoute(publishFlow));
router.post('/fin-assistant/flows/:id/unpublish', asyncRoute(unpublishFlow));
router.delete('/fin-assistant/flows/:id', asyncRoute(deleteFlow));
router.post('/fin-assistant/flows/:id/steps', validateBody(createStepSchema), asyncRoute(createStep));
router.patch('/fin-assistant/flows/:id/steps/:stepId', validateBody(updateStepSchema), asyncRoute(updateStep));
router.delete('/fin-assistant/flows/:id/steps/:stepId', asyncRoute(deleteStep));
router.get('/fin-assistant/audit-log', asyncRoute(listAuditLog));

export default router;
