import path from 'node:path';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import cookieParser from 'cookie-parser';

import { env } from './config/env.js';
import routes from './routes/index.js';
import { notFound } from './middleware/notFound.js';
import { errorHandler } from './middleware/errorHandler.js';
import { maintenanceGate } from './middleware/maintenance.js';
import { MAX_NOTIFICATION_BYTES } from './constants/payments.js';

export function createApp() {
  const app = express();
  app.set('trust proxy', env.trustProxy);

  // The default policy, with the two things the in-browser payslip reader needs
  // (P8-30): WebAssembly for the OCR engine (`'wasm-unsafe-eval'` allows ONLY
  // WebAssembly, not eval of strings) and workers from this same site. Nothing
  // third-party is allowed: the OCR engine, its worker and its language data are
  // served from `/ocr`.
  app.use(
    helmet({
      contentSecurityPolicy: {
        useDefaults: true,
        directives: { 'script-src': ["'self'", "'wasm-unsafe-eval'"], 'worker-src': ["'self'", 'blob:'] },
      },
    }),
  );
  app.use(
    cors({
      origin: env.corsOrigin,
      credentials: true,
    })
  );
  // Payment notifications (P3-09) are read RAW: the provider signs the exact
  // bytes it sends, so the body must not be parsed and re-serialised first.
  app.use('/api/payments/webhook', express.raw({ type: () => true, limit: MAX_NOTIFICATION_BYTES }));
  // Articles and lessons can be long (validation allows 200 000 characters, up to
  // 3 bytes each): the administration accepts 1 MB, everything else keeps the
  // 100 kB default so a public route cannot be fed huge bodies.
  app.use('/api/admin', express.json({ limit: '1mb' }));
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  app.use(cookieParser());
  if (env.logRequests) app.use(morgan(env.isProduction ? 'combined' : 'dev'));

  app.use(maintenanceGate);
  // Never kept by a cache (recette R11-16): the host's nginx stored GET answers
  // of the API and served them again after a change — a movement pointed, an
  // income added, then the list came back as it was before (304). Every API
  // answer belongs to one person at one moment: none may be stored or shared.
  app.use('/api', (req, res, next) => {
    res.set('Cache-Control', 'no-store, private');
    res.set('Pragma', 'no-cache');
    res.vary('Cookie');
    next();
  });
  app.use('/api', routes);

  // Single-host deployment: the built website is served next to the API. Hashed
  // bundles are cached for a year; index.html never is, so a new build shows at once.
  // Every other non-API address returns index.html and React Router takes over.
  if (env.clientDir) {
    app.use('/assets', express.static(path.join(env.clientDir, 'assets'), { immutable: true, maxAge: '1y' }));
    app.use(express.static(env.clientDir, { index: false }));
    app.get(/^\/(?!api(\/|$)).*/, (req, res) => {
      res.set('Cache-Control', 'no-cache');
      res.sendFile(path.join(env.clientDir, 'index.html'));
    });
  }

  app.use(notFound);
  app.use(errorHandler);

  return app;
}
