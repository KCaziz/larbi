import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

dotenv.config();

function parseTrustProxy(value) {
  if (!value) return false;
  if (value === 'true') return true;
  if (value === 'false') return false;
  const n = Number(value);
  return Number.isFinite(n) ? n : value;
}

const required = ['DATABASE_URL', 'JWT_SECRET'];

for (const key of required) {
  if (!process.env[key]) {
    throw new Error(`Missing required environment variable: ${key}`);
  }
}

export const env = {
  nodeEnv: process.env.NODE_ENV || 'development',
  port: Number(process.env.PORT) || 4000,
  databaseUrl: process.env.DATABASE_URL,
  jwtSecret: process.env.JWT_SECRET,
  jwtExpiresInSeconds: Number(process.env.JWT_EXPIRES_IN_SECONDS) || 60 * 60 * 24 * 7,
  corsOrigin: (process.env.CORS_ORIGIN || 'http://localhost:5173')
    .split(',')
    .map((origin) => origin.trim()),
  // Express's own "trust proxy" setting: how many reverse-proxy hops (ngrok, nginx,
  // a load balancer...) stand between a visitor and this server. Needed so
  // express-rate-limit keys requests by the VISITOR's address instead of the
  // proxy's (otherwise every visitor behind that proxy shares one rate-limit
  // bucket). false (default) = trust nothing: correct for direct local dev,
  // where there is no proxy in front at all.
  trustProxy: parseTrustProxy(process.env.TRUST_PROXY),
  isProduction: process.env.NODE_ENV === 'production',
  // One access-log line per request. Off for the automated tests (LOG_REQUESTS=false).
  logRequests: process.env.LOG_REQUESTS !== 'false' && process.env.NODE_ENV !== 'test',
  // Private storage for uploaded media. Lives OUTSIDE anything served
  // statically: files are only reachable through authorised API routes.
  storageDir: path.resolve(
    process.env.STORAGE_DIR || path.join(path.dirname(fileURLToPath(import.meta.url)), '../../storage'),
  ),
  // E-mail (newsletter confirmation, contact form). "smtp" sends for real through the
  // mailbox of the domain (contact@fincludia.com); "console" keeps mails in memory /
  // prints them (development and tests only); "none" refuses to send (the default in
  // production when no mailbox is configured, so nothing is ever faked).
  mailDriver: process.env.MAIL_DRIVER || (process.env.NODE_ENV === 'production' ? 'none' : 'console'),
  smtpHost: process.env.SMTP_HOST || null,
  smtpPort: Number(process.env.SMTP_PORT) || 465,
  // 465 = TLS from the first byte; 587 = STARTTLS. Deduced from the port unless said.
  smtpSecure: process.env.SMTP_SECURE ? process.env.SMTP_SECURE === 'true' : (Number(process.env.SMTP_PORT) || 465) === 465,
  smtpUser: process.env.SMTP_USER || null,
  smtpPassword: process.env.SMTP_PASSWORD || null,
  // Sender shown to the recipient; defaults to the mailbox itself.
  mailFrom: process.env.MAIL_FROM || (process.env.SMTP_USER ? `FINCLUDIA <${process.env.SMTP_USER}>` : null),
  // Mailbox that receives the messages of the contact form (unset = stored only).
  contactInbox: process.env.CONTACT_INBOX || null,
  // Public address of the website, used to build the links written in e-mails.
  publicUrl: (process.env.PUBLIC_URL || (process.env.CORS_ORIGIN || 'http://localhost:5173').split(',')[0]).trim().replace(/\/+$/, ''),
  maxImageBytes: Number(process.env.MAX_IMAGE_BYTES) || 5 * 1024 * 1024,
  maxDocumentBytes: Number(process.env.MAX_DOCUMENT_BYTES) || 25 * 1024 * 1024,
  maxVideoBytes: Number(process.env.MAX_VIDEO_BYTES) || 300 * 1024 * 1024,
  // Payment provider (P3-09): "fake" (simulated, development and tests only) or
  // "none" (default in production until the client's provider is wired, P3-10).
  paymentProvider: process.env.PAYMENT_PROVIDER || (process.env.NODE_ENV === 'production' ? 'none' : 'fake'),
  // Web Push (P8-24): the VAPID keys that identify this server to the browsers'
  // push services. Unset = the feature is OFF and says so (nothing is faked).
  // Generate once with `npm run push:keys`; keep the private key in the
  // environment of the application, never in the code or the browser.
  vapidPublicKey: process.env.VAPID_PUBLIC_KEY || null,
  vapidPrivateKey: process.env.VAPID_PRIVATE_KEY || null,
  vapidSubject: process.env.VAPID_SUBJECT || null,
  // Built website (client/dist) served by this same process, for single-host
  // deployments (cPanel...). Unset = API only (development: Vite serves the site).
  clientDir: process.env.CLIENT_DIR
    ? path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..', process.env.CLIENT_DIR)
    : null,
};

if (!['console', 'none', 'smtp'].includes(env.mailDriver)) {
  throw new Error('MAIL_DRIVER must be "smtp", "console" or "none"');
}
if (env.mailDriver === 'smtp' && !(env.smtpHost && env.smtpUser && env.smtpPassword)) {
  throw new Error('MAIL_DRIVER=smtp needs SMTP_HOST, SMTP_USER and SMTP_PASSWORD');
}

if (!['none', 'fake'].includes(env.paymentProvider)) {
  throw new Error('PAYMENT_PROVIDER must be "none" or "fake" (no real provider is wired yet, see P3-10)');
}
// The simulated provider accepts any payment: it must never run in production.
if (env.paymentProvider === 'fake' && env.isProduction) {
  throw new Error('PAYMENT_PROVIDER=fake is for development and tests only');
}

if (env.jwtSecret.length < 32) {
  throw new Error('JWT_SECRET must be at least 32 characters');
}
